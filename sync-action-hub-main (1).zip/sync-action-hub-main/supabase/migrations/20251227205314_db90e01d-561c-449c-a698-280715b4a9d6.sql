-- Enable realtime for attachments table
ALTER PUBLICATION supabase_realtime ADD TABLE public.attachments;